

public interface CarFactory {
	
    public abstract Car buildCar(String model, String wheel, String engine,String colour,String variant,String fuel); 	
}