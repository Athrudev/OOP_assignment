
public interface Car {
	  
	 
		public String getModel();
		

		public void setWheel(String wheel);
		

		public String getWheel();
		
		
		public void setEngine(String engine);
		

		public String getEngine();
		
		
		public String getColour();
		 
		public void setColour(String colour);
		 
		public String getVariant();
		 
		public void setVariant(String variant);
		 
		public String getFuel();
		 
		public void setFuel(String fuel);
		 
		public String getdata();
		 
		
	   
	}